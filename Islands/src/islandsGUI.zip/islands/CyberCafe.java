package islands;

public interface CyberCafe {
	public void sendMessage(String personID)  ; 
	public void receiveMessage(String personID)  ;
}
