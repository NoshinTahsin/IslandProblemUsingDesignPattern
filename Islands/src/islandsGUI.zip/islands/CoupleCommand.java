package islands;

public interface CoupleCommand 
{
    public void execute(); 
} 


