package islands;

public class TakeVowCommand implements CoupleCommand {
	
	Couples couple; 
	  
    // The constructor is passed the light it 
    // is going to control. 
    public TakeVowCommand(Couples couple) 
    { 
       this.couple = couple; 
    } 
    public void execute() 
    { 
       couple.takeVow(); 
    } 

}
