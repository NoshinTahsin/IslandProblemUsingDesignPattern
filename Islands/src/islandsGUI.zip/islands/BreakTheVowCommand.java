package islands;

public class BreakTheVowCommand implements CoupleCommand {
	
	Couples couple; 
	  
    // The constructor is passed the light it 
    // is going to control. 
    public BreakTheVowCommand(Couples couple) 
    { 
       this.couple = couple; 
    } 
    public void execute() 
    { 
       couple.breakVow(); 
    } 
}
