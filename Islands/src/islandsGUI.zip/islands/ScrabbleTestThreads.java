package islands;

public class ScrabbleTestThreads{
	
	public static void main(String[] args){
		
		// Create a new Thread created using the Runnable interface
		// Execute the code in run after 10 seconds
				
		Runnable getWater = new GetWater();
				
		Runnable getWaterAgain = new GetWater();
				
		// Call for the code in the method run to execute
				
		new Thread(getWater).start();
		new Thread(getWaterAgain).start();
		
	}
	
}
