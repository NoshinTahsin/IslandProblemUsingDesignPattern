package islands;

import java.util.LinkedList;

import javax.swing.*;

public class WellTest {
	
	public static void ScrabbleMain() {
		
		// How you create a new instance of Singleton
		JFrame f=new JFrame();
		boolean loop=true;
		
		while(loop)
			{
			Singleton newInstance = Singleton.getInstance();
			
		
		// Get unique id for instance object
		
		//System.out.println("1st Instance ID: " + System.identityHashCode(newInstance));
		
		// Get all of the letters stored in the List
		
		//progressbar e length
		System.out.println(newInstance.getLetterList());
		
		int length=newInstance.getLetterList().size();
		
		if(length>8)
		{
			//Insert 7 from field
			LinkedList<String> playerOneTiles = newInstance.getTiles(7);
		
			//System.out.println("Player 1: " + playerOneTiles);
		
			//System.out.println(newInstance.getLetterList());
			length=newInstance.getLetterList().size();
			 JOptionPane.showMessageDialog(f,"Water remaining "+length+" unit");  
		}
		
		else
		{
			loop=false;
			//System.out.println("Praying for rain");
			 JOptionPane.showMessageDialog(f,"Praying for rain");  
		}
	}
		
		// Try to make another instance of Singleton
		// This doesn't work because the constructor is private
		
		// Singleton instanceTwo = new Singleton();
		
		// Try getting a new instance using getInstance
		
		/*Singleton instanceTwo = Singleton.getInstance();
		
		// Get unique id for the new instance object
		
		System.out.println("2nd Instance ID: " + System.identityHashCode(instanceTwo));
		
		// This returns the value of the first instance created
		
		System.out.println(instanceTwo.getLetterList());
		
		// Player 2 draws 7 tiles
		
		LinkedList<String> playerTwoTiles = newInstance.getTiles(7);
		
		System.out.println("Player 2: " + playerTwoTiles);*/
		
	}
	
}