package islands;

public interface IslandPlan {
	
	public void setFlora(String Flora);
	
	public void setFauna(String Fauna);
	
	public void setEnvironment(String Environment);
	
	public void setHut(String Hut);

}
