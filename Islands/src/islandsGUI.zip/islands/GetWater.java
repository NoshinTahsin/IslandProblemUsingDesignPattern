package islands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

import javax.swing.*;

public class GetWater extends JFrame implements Runnable {
	
	 
	 
	JFrame f=new JFrame();
        
       
	
	public void run(){

	 
	    
	    // How you create a new instance of Singleton
			
			Singleton newInstance = Singleton.getInstance();
			
			// Get unique id for instance object
			
			//System.out.println("1st Instance ID: " + System.identityHashCode(newInstance));
			
			// Get all of the letters stored in the List
			
			//ProgressBar=letterList er length
			int progressLength=newInstance.getLetterList().size();
			//jb.setValue(progressLength);  
			
			//System.out.println(newInstance.getLetterList());
			
			//Take input 7 from input field
			
			   
				        	LinkedList<String> playerOneTiles = newInstance.getTiles(7);  
				        	    
				        	 JOptionPane.showMessageDialog(f,"Got water");  
				        
				 
				         
					
			 
				
		 
			
			
			//System.out.println("Player 1: " + playerOneTiles);
		
			//JOptionPane/messageDialog
			//System.out.println("Got Tiles");
	}
	
}