package islands;

public interface DisasterManagementCommand {
	void move();
}
